﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UnitTestProject1
{
    class Calculator
    {
        internal int divide(int p1, int p2)
        {
            throw new NotImplementedException();
        }
    }
}
